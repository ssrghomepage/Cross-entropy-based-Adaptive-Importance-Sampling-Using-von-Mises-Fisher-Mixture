function [output]=CEAISvMFM(Main,ii)
%% Initialize Input

N_rvs = Main.numb;%% Number of random variables
N=Main.Nint;%% Size of iterative pre-sample
K=Main.K;
if ii==1
mu_init = randUniformOnSphere(N_rvs,K);
k_initratio=5;
k_init = k_initratio*ones(1,K);
alpha_init=(1/K)*ones(1,K);
else
    mu_init =Main.mu;
    k_init =Main.kapa;
    alpha_init=Main.alp;
end
mu_cur = mu_init;
k_cur = k_init;
alpha_cur=alpha_init;
flag=0;
R=sqrt(N_rvs);
g_roh=Main.g_roh;
count=0;

%% Pre-sampling for the first threshold

if ii==1
while 1    
u=R*randUniformOnSphere(N_rvs,N);
id=Id_CEAISvMFM(u,Main);
count=count+N;
Idtemp=id.G_x;
H_x = (Idtemp<= 0);
if sum(H_x)/N_rvs < 0.5
    N=round(0.5*N*N_rvs/sum(H_x));    
else
    break
end
end  
 for k=1:K
    lvMFpdf(k,:)=logVmfPdf(u/R,mu_init(:,k),k_init(k));          
 end 
    tlvMFpdf=lvMFpdf-mean(mean(lvMFpdf,2),1); 
    tsum=0;
    for k=1:K
       tsum=tsum+alpha_init(k)*exp(tlvMFpdf(k,:));
    end
    for k=1:K
        postPDF(k,:)=alpha_init(k)*exp(tlvMFpdf(k,:))./tsum;
    end    
  for k=1:K
      alpha_cur(k)=postPDF(k,:)*H_x/sum(H_x);
      temps=norm(u*(H_x.*postPDF(k,:)'));
      mu_cur(:,k)=u*(H_x.*postPDF(k,:)')/temps;
      tempr=temps/(alpha_cur(k)*sum(H_x)*R);
      k_cur(k)=(tempr*N_rvs-(tempr)^3)/(1-(tempr)^2);       
  end    
  alpha_cur=alpha_cur./sum(alpha_cur);
clear u H_x;
for k=1:K
jjj = find(mnrnd(1,alpha_cur));
u(:,(k-1)*round(N/K)+1:k*round(N/K))=R*vsamp(mu_cur(:,jjj),k_cur(jjj),round(N/K))';
end
  id=Id_CEAISvMFM(u,Main);
  count=count+K*round(N/K);
Idtemp=id.G_x;
H_x = (Idtemp<= 0);
if sum(H_x) >= g_roh*K*round(N/K)  
    flag=1;
    output.mu=mu_cur;
    output.ku=k_cur;
    output.alpha=alpha_cur;
end
   

while flag~=1        
    clear lvMFpdf tsum postPDF
    count=count+K*round(N/K);
     mu_init=mu_cur;
    k_init=k_cur;
    alpha_init=alpha_cur;
    alpha_init = alpha_init./sum(alpha_init); 
  for k=1:K
         lvMFpdf(k,:)=logVmfPdf(u/R,mu_init(:,k),k_init(k));
  end  
  tlvMFpdf=lvMFpdf-mean(mean(lvMFpdf,2),1);   
  tsum=0;
    for k=1:K
       tsum=tsum+alpha_init(k)*exp(tlvMFpdf(k,:));
    end  
  tH_x=H_x;
  ttH_x=H_x;
  tH_x(tH_x==0)=Inf;
  ttH_x(ttH_x==0)=-Inf;
  maxa=max(log(tsum).*ttH_x');  
  mina=min(log(tsum).*tH_x');
  clear tH_x ttH_x  
  flag1=0;
  fr=(maxa-mina)/5;
  frt=round(maxa-mina)/5;
   if frt>=1
        flag1=1;
   end
    for k=1:K
       postPDF(k,:)=alpha_init(k)*exp(tlvMFpdf(k,:))./tsum;
    end   
    rt=max(max(tsum)); 
    for k=1:K
      if flag1==1  
      W=rt^(1/(fr))*ones(K*round(N/K),1)./tsum'.^(1/(fr));
      else
      W=rt*ones(K*round(N/K),1)./tsum';    
      end
      W=W/norm(W);
      alpha_cur(k)=postPDF(k,:)*(H_x.*W)/sum(H_x.*W);
      temps=norm(u*(H_x.*postPDF(k,:)'.*W));
      mu_cur(:,k)=u*(H_x.*postPDF(k,:)'.*W)/temps;
      tempr=temps/(alpha_cur(k)*sum(H_x.*W)*R);
      k_cur(k)=(tempr*N_rvs-tempr^3)/(1-tempr^2);
      if k_cur(k)>k_init(k)
      k_cur(k)=(k_cur(k)+k_init(k))/2;
      end    
    end
for k=1:K
    jjj = find(mnrnd(1,alpha_init));
    u(:,(k-1)*round(N/K)+1:k*round(N/K))=R*vsamp(mu_init(:,jjj),k_init(jjj),round(N/K))';
end

id=Id_CEAISvMFM(u,Main);
count=count+K*round(N/K);
Idtemp=id.G_x;
H_x = (Idtemp<= 0);
if sum(H_x) >= g_roh*K*round(N/K) 
    flag=1;    
    output.mu=mu_cur;
    output.ku=k_cur;
    output.alpha=alpha_cur;
end
end

else

%% pre-sampling for subsequent thresholds using directions found by the previous threshold
while 1
clear u H_x    
for k=1:K
jjj = find(mnrnd(1,alpha_cur));
u(:,(k-1)*round(N/K)+1:k*round(N/K))=R*vsamp(mu_cur(:,jjj),k_cur(jjj),round(N/K))';
end
id=Id_CEAISvMFM(u,Main);
count=count+K*round(N/K);
Idtemp=id.G_x;
H_x = (Idtemp<= 0);
if sum(H_x)/N_rvs < 0.5
    N=round(0.5*N*N_rvs/sum(H_x));
else
    break
end
end

if sum(H_x) >= g_roh*K*round(N/K)
    flag=1;
     mu_init=mu_cur;
    k_init=k_cur;
    alpha_init=alpha_cur;
  for k=1:K
        lvMFpdf(k,:)=logVmfPdf(u/R,mu_init(:,k),k_init(k));          
  end   
  tlvMFpdf=lvMFpdf-mean(mean(lvMFpdf,2),1); 
  tsum=0;
  for k=1:K
        tsum=tsum+alpha_init(k)*exp(tlvMFpdf(k,:));
  end  
  tH_x=H_x;
  ttH_x=H_x;
  tH_x(tH_x==0)=Inf;
  ttH_x(ttH_x==0)=-Inf;
  maxa=max(log(tsum).*ttH_x');  
  mina=min(log(tsum).*tH_x');
  clear tH_x ttH_x  
  flag1=0;
  fr=(maxa-mina)/5;
  frt=round(maxa-mina)/5;
  if frt>=1
        flag1=1;
   end
  for k=1:K
         postPDF(k,:)=alpha_init(k)*exp(tlvMFpdf(k,:))./tsum;
  end   
    rt=max(max(tsum)); 
    for k=1:K
      if flag1==1  
      W=rt^(1/(1*fr))*ones(K*round(N/K),1)./tsum'.^(1/(fr));
      else
      W=rt^(1/(1*fr))*ones(K*round(N/K),1)./tsum';    
      end
      W=W/norm(W);
      alpha_cur(k)=postPDF(k,:)*(H_x.*W)/sum(H_x.*W);
      temps=norm(u*(H_x.*postPDF(k,:)'.*W));
      mu_cur(:,k)=u*(H_x.*postPDF(k,:)'.*W)/temps;
      tempr=temps/(alpha_cur(k)*sum(H_x.*W)*R);       
      k_cur(k)=(tempr*N_rvs-tempr^3)/(1-tempr^2);
      if k_cur(k)>k_init(k)
      k_cur(k)=(k_cur(k)+k_init(k))/2;
      end;
    end
    output.mu=mu_cur;
    output.ku=k_cur;
    output.alpha=alpha_cur;
end 

while flag~=1
    mu_init=mu_cur;
    k_init=k_cur;
    alpha_init=alpha_cur; 
  for k=1:K
        lvMFpdf(k,:)=logVmfPdf(u/R,mu_init(:,k),k_init(k));          
  end   
  tlvMFpdf=lvMFpdf-mean(mean(lvMFpdf,2),1); 
  tsum=0;
  for k=1:K
        tsum=tsum+alpha_init(k)*exp(tlvMFpdf(k,:));
  end  
  tH_x=H_x;
  ttH_x=H_x;
  tH_x(tH_x==0)=Inf;
  ttH_x(ttH_x==0)=-Inf;
  maxa=max(log(tsum).*ttH_x');  
  mina=min(log(tsum).*tH_x');
  clear tH_x ttH_x  
  flag1=0;
  fr=(maxa-mina)/5;
  frt=round(maxa-mina)/5;
  if frt>=1
        flag1=1;
   end
  for k=1:K
         postPDF(k,:)=alpha_init(k)*exp(tlvMFpdf(k,:))./tsum;
  end   
    rt=max(max(tsum)); 
    for k=1:K
      if flag1==1  
          W=rt^(1/(1*fr))*ones(K*round(N/K),1)./tsum'.^(1/(fr));
      else
      W=rt^(1/(1*fr))*ones(K*round(N/K),1)./tsum';   
      end
      W=W/norm(W);
      alpha_cur(k)=postPDF(k,:)*(H_x.*W)/sum(H_x.*W);
      temps=norm(u*(H_x.*postPDF(k,:)'.*W));
      mu_cur(:,k)=u*(H_x.*postPDF(k,:)'.*W)/temps;
      tempr=temps/(alpha_cur(k)*sum(H_x.*W)*R);       
      k_cur(k)=(tempr*N_rvs-tempr^3)/(1-tempr^2);
      if k_cur(k)>k_init(k)
      k_cur(k)=(k_cur(k)+k_init(k))/2;
     end   
    end
    alpha_cur = alpha_cur./sum(alpha_cur);
    clear u;
    clear H_x;
for k=1:K
jjj = find(mnrnd(1,alpha_cur));
u(:,(k-1)*round(N/K)+1:k*round(N/K))=R*vsamp(mu_cur(:,jjj),k_cur(jjj),round(N/K))';
end
id=Id_CEAISvMFM(u,Main);
count=count+K*round(N/K);
Idtemp=id.G_x;
H_x = (Idtemp<= 0);
if sum(H_x) >= g_roh*K*round(N/K) 
    flag=1;    
    output.mu=mu_cur;
    output.ku=k_cur;
    output.alpha=alpha_cur;
end 
end
end

figure(ii);
plot(output.mu);
title('Mean Direction');
fprintf('\t- Run final importance sampling\n'); 
%% run final importance sampling  

[Output]=FinalvMFM(Main,output);
output.Pf=Output.Pf;
output.Bfo=Output.beta;
output.num=Output.num;
output.num0=count;
output.Nint=N;
end