function pdf=loguniformSpherePDF(R,Dim)
A=log(Dim)+log(pi^(Dim/2))+log(R^(Dim-1))-gammaln(Dim/2+1);
pdf=-A;
end