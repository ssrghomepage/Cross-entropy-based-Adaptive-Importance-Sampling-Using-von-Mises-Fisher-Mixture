The codes show how to use CE-AIS-vMFM to solve a high-dimensional toy example of system reliability analysis

The codes are based on the paper "Wang Z and Song J 2016" published at Structural Safety

Run TestExample.m

The performance function is defined in Id_CEAISvMFM.m, one could modify this function to solve other problems of interest
