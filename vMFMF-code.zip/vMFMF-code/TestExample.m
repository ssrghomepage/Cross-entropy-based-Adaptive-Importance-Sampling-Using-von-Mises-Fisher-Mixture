%This script shows how to use the CE-AIS-VMFM sampling method to solve a high-dimensional toy example of system reliability analysis
%This script is written by Ziqi Wang based on the paper "Wang Z and Song J 2016" published at Structural Safety
clear
clc
tic 
Main.numb=100;%% number of random variables
Amplitude=[1.0  2.0  3.0  4.0];%% A sequence of thresholds of interest 
Main.AnalyzeMode=1;%=1,use AIS-CE-vMFM-1; =2 use AIS-CE-vMFM-2;
Main.Nint=20*(Main.numb);%% Size of the iterative pre-sample,we suggest Nint>5*n, we might need larger Main.Nint for complex system problems
Main.K=Main.numb/2;%% Number of vMFs in the mixture
Main.g_roh=0.3;%% convergence criterion for for pre-sampling, we suggest 0.05<g_roh<0.4
Main.cov=0.1;%% c.o.v level for final sampling
for ii=1:numel(Amplitude)
    ii
    Main.A=Amplitude(ii);    
    if Main.AnalyzeMode==1||Main.AnalyzeMode==2
    tic
    [Output]=CEAISvMFM(Main,ii);
    Main.mu=Output.mu;
    Main.Nint=Output.Nint;
    Main.kapa=Output.ku;
    Main.alp=Output.alpha;
    Main.MU{ii}=Output.mu;
    Main.KAPA{ii}=Output.ku;
    Main.ALP{ii}=Output.alpha;  
    num0(ii)=Output.num0;
    num(ii)=Output.num; 
    else 
    fprintf('require the correct AnalyzeMode value(1,2 are valid values)'); 
    break;
    end    
    CPUtimeIt=toc;    
    BFO(ii)=Output.Bfo;
    TIME(ii)=CPUtimeIt;
end 
CPUtime=sum(TIME)