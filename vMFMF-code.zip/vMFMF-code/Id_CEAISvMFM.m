function [output] = Id_CEAISvMFM(u,Main)
    u=u';
    G_xt(:,1) = Main.A*sqrt(Main.numb) - sum(u,2);
    G_xt(:,2) = Main.A*sqrt(Main.numb) + sum(u,2);    
%     temp=0;
%     for ii=1:Main.numb
%         temp=temp+(-1)^ii*u(:,ii);
%     end
%     G_xt(:,3) = Main.A*sqrt(Main.numb) + temp;
%     temp1=0;
%     for ii=1:Main.numb
%         temp1=temp1+(-1)^(ii+1)*u(:,ii);
%     end
%     G_xt(:,4) = Main.A*sqrt(Main.numb) + temp1;    
    output.G_x=min(G_xt,[],2);
end