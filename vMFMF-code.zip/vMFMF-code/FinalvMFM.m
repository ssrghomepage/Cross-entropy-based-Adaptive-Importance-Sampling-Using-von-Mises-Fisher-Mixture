function [Output]=FinalvMFM(Main,output)
%final inportant sampling using given parameters

%--INPUTS--
N_rvs = Main.numb;
K = Main.K;
mu_cur = output.mu;
ku = output.ku;
alpha = output.alpha;
cov_level = Main.cov;
R=sqrt(N_rvs);

%--initializing parameters--
lpdfR=loguniformSpherePDF(1,N_rvs);
N =100;
n = 0;
Nr=1;
convergence_check = 1;

%start IS
if Main.AnalyzeMode==1
while convergence_check > cov_level 
    n = n + 1;
    
    %show proccess bar
    if n > 1000
        fprintf('\t-Proccessing...(use Ctrl+C to break)\n\t');
        break;
    end   
   
  clear u;
jjj = find(mnrnd(1,alpha));
u=R*vsamp(mu_cur(:,jjj),ku(jjj),N);
  u=u';
id=Id_CEAISvMFM(u,Main);
Idtemp=id.G_x;
H_x = (Idtemp<= 0);        
%compute updated pdf, h(x)
    h_x = 0;
    for k = 1:K;
         lvMFpdf(k,:)=logVmfPdf(u/R,mu_cur(:,k),ku(k));           
    end
    count=0;
    while max(max(lvMFpdf))>700
    lvMFpdf=lvMFpdf-50;
    count=count+1;
    end    
    for k=1:K
     h_temp = alpha(k)*exp(lvMFpdf(k,:));
        h_x = h_x + h_temp;
    end
    lh_x=log(h_x);
        clear h_temp;
    %comput the failure probability of each run
   Pfn(n,1) = sum(H_x.*exp(-50*count+lpdfR-lh_x'))/N;
    clear u h_x f_x H_x;
    
    %compute current Pf
    Pf_cur = sum(Pfn)/n;
cov_Pf(n,1) = std(Pfn)/Pf_cur/sqrt(n);
convergence = cov_Pf(end);    
    if n>5
    convergence_check = convergence;
    end   
end
else
  % Perform IS in conjunction with MCS
 while convergence_check > cov_level 
    n = n + 1;    
    %show proccess bar
    if n>1000
        fprintf('\t-Proccessing...(use Ctrl+C to break)\n\t');
        break;
    end       
    clear u r
    r=chi2rnd(N_rvs,1,Nr);
    r=sqrt(r);
 for rk=1:Nr
jjj = find(mnrnd(1,alpha));
u=r(rk)*vsamp(mu_cur(:,jjj),ku(jjj),N);
 u=u';
id=Id_CEAISvMFM(u,Main);
Idtemp=id.G_x;
H_x = (Idtemp<= 0);       
    %compute updated pdf, h(x)
    h_x = 0;
    for k = 1:K;
         lvMFpdf(k,:)=logVmfPdf(u/r(rk),mu_cur(:,k),ku(k));           
    end
    count=0;
    while max(max(lvMFpdf))>700
    lvMFpdf=lvMFpdf-50;
    count=count+1;
    end    
    for k=1:K
     h_temp = alpha(k)*exp(lvMFpdf(k,:));
        h_x = h_x + h_temp;
    end
    lh_x=log(h_x);
        clear h_temp;
%comput the failure probability of each run
Pfrk(Nr*(n-1)+rk,1) = sum(H_x.*exp(-50*count+lpdfR-lh_x'))/N;
    clear u h_x f_x H_x;
 end
 Pfn(n,1) = mean(Pfrk(Nr*(n-1)+1:Nr*n));
  Pf_cur = mean(Pfn);
    cov_Pf(n,1) = std(Pfn)/Pf_cur/sqrt(n);
    convergence= cov_Pf(end);
    if n>5
    convergence_check = convergence;
    end  
 end
end

ttt = 0;
Failure_Prob = Pf_cur(end);
while Failure_Prob < 1
    ttt = ttt + 1; 
    Failure_Prob = Failure_Prob*10;
end
Output.Pf = Pf_cur(end);
Output.beta=-norminv(Output.Pf);
Output.ci_95 = [(1-2*cov_Pf(n))*Pf_cur(end),(1+2*cov_Pf(n))*Pf_cur(end)];
if Main.AnalyzeMode==1
Output.num = n*N;
else
Output.num = n*N*Nr;   
end

uuu = 0;
low_bound = Output.ci_95(1);
while low_bound < 1
    uuu = uuu + 1;
    low_bound = low_bound*10;
end

vvv = 0;
up_bound = Output.ci_95(2);
while up_bound < 1
    vvv = vvv + 1;
    up_bound = up_bound*10;
end

fprintf('\t- Failure probability \t :\t%1.2f x 10^-%i\n', Failure_Prob,ttt);
fprintf('\t- Reliability index \t :\t%i\n', Output.beta);
fprintf('\t- 95%% Confidence Interval:\t[%1.2f x 10^-%i, %1.2f x 10^-%i]\n',...
    low_bound,uuu,up_bound,vvv);
fprintf('\t- Number of samples \t :\t%i\n\n', Output.num);
end